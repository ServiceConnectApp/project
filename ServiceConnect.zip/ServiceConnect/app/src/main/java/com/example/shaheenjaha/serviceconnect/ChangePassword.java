package com.example.shaheenjaha.serviceconnect;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ChangePassword extends AppCompatActivity {
    Button change_pswd;
    EditText old_pswd,new_pswd,confirm_pswd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        change_pswd=findViewById(R.id.buttonChange);
        old_pswd=findViewById(R.id.editTextOldPassword);
        new_pswd=findViewById(R.id.editTextNewPassword);
        confirm_pswd=findViewById(R.id.editTextConfirmPassword);
        change_pswd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
