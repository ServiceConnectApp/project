package com.example.shaheenjaha.serviceconnect;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ChangePhone extends AppCompatActivity {
    Button change_ph;
    EditText old_ph,new_ph,confirm_ph;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_phone);
        change_ph=findViewById(R.id.buttonChangePh);
        old_ph=findViewById(R.id.editTextOldPh);
        new_ph=findViewById(R.id.editTextNewPh);
        confirm_ph=findViewById(R.id.editTextConfirmPh);
        change_ph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
