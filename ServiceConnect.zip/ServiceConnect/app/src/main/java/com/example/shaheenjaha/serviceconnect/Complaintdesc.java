package com.example.shaheenjaha.serviceconnect;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Complaintdesc extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    String[] category = {"Please select complaint type", "Electricity", "Plumbing", "Carpentry", "Others"};
    Spinner spinner;
    EditText complaint;
    ImageView cam;
    ImageView gallery;
    Button submit;
    String code, cat;
    String image = "no image";
    int GAL = 101;
    int CAM = 100;
    ImageView img=null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaintdesc);
        spinner = findViewById(R.id.spinner);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, category);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        cam = findViewById(R.id.cameraimg);
        gallery = findViewById(R.id.galleryimg);
        complaint = findViewById(R.id.complain);
        submit = findViewById(R.id.sub);
        img = findViewById(R.id.img);
//        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
//        setProgressBarIndeterminateVisibility(true);

        cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAM);
            }
        });
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(intent, 10);
//                Intent intent=new Intent();
//                intent.setType("image/*");
//                intent.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(intent,GAL);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("student_data", Context.MODE_PRIVATE);
                new AsynciClass().execute(sharedPreferences.getString("s_reg_no", "default"), cat, complaint.getText().toString(), image, code, sharedPreferences.getString("s_room_no", "default"), sharedPreferences.getString("s_gender", "default"));
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap;
        if(requestCode == CAM && resultCode == RESULT_OK && data!=null)
        {
            bitmap = (Bitmap) data.getExtras().get("data");
            img.setImageBitmap(bitmap);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,50,byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            image = Base64.encodeToString(byteArray, Base64.DEFAULT);
        }
        else if(requestCode == GAL && resultCode == RESULT_OK && data!=null)
        {
            Uri path = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),path);
                int height = bitmap.getHeight();
                int width = bitmap.getWidth();
                if(height > 2000 && width > 2000){

                }
                else {
                    Uri selectedImage = data.getData();
                    String[] filePath = { MediaStore.Images.Media.DATA };
                    Cursor c = getContentResolver().query(selectedImage,filePath, null, null, null);
                    c.moveToFirst();
                    int columnIndex = c.getColumnIndex(filePath[0]);
                    String picturePath = c.getString(columnIndex);
                    c.close();
                    Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                    Log.w("path of image", picturePath+"");
                    img.setImageBitmap(thumbnail);
                    img.setImageBitmap(bitmap);
                }
                //byte[] decodedString = Base64.decode(bitmap,Base64.DEFAULT);
                //image = BitmapFactory.decodeByteArray(decodedString,0,decodedString.length);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        cat=category[position];
        switch (position){
            case 0:code=" ";break;
            case 1:code="EL";break;
            case 2:code="PL";break;
            case 3:code="CR";break;
            case 4:code="OT";break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast.makeText(Complaintdesc.this,"Please select something",Toast.LENGTH_LONG).show();
    }

    class AsynciClass extends AsyncTask<String,String,String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... arg) {
            String reg = arg[0];
            String categ = arg[1];
            String desc = arg[2];
            String img = arg[3];
            String code = arg[4];
            String room = arg[5];
            String gen = arg[6];
            String data="";
            int tmp;
            try{
                URL url;
                url = new URL("https://aec.edu.in/service_connect/app/RegisterComplain.php");
                String urlParams = "regNo="+reg+"&category="+categ+"&description="+desc+"&image="+img+"&code="+code+"&room="+room+"&gender="+gen;
                HttpURLConnection httpURLConnection=(HttpURLConnection) url.openConnection();
                httpURLConnection.setDoOutput(true);
                OutputStream os=httpURLConnection.getOutputStream();
                os.write(urlParams.getBytes());
                os.flush();
                os.close();
                InputStream is=httpURLConnection.getInputStream();
                while ((tmp=is.read())!=-1){
                    data+=(char)tmp;
                }
                is.close();
                httpURLConnection.disconnect();
                return data;
            }
            catch (MalformedURLException e){
                e.printStackTrace();
                return "Exception:"+e.getMessage();
            }
            catch (IOException e){
                e.printStackTrace();
                return "Exception:"+e.getMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
        }
    }

}


