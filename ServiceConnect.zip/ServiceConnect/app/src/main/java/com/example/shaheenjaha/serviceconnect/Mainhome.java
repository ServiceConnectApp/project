package com.example.shaheenjaha.serviceconnect;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class Mainhome extends AppCompatActivity {
    CardView status,add,history,contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainhome);
        add=findViewById(R.id.android_card_view1);
        status=findViewById(R.id.android_card_view2);
        history=findViewById(R.id.android_card_view3);
        contact=findViewById(R.id.android_card_view4);
        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i_stat = new Intent(Mainhome.this, Status.class);
                startActivity(i_stat);

            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i_add = new Intent(Mainhome.this, Complaintdesc.class);
                startActivity(i_add);

            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i_hist = new Intent(Mainhome.this, Status.class);
                startActivity(i_hist);

            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i_cont = new Intent(Mainhome.this, Status.class);
                startActivity(i_cont);

            }
        });

    }
}
