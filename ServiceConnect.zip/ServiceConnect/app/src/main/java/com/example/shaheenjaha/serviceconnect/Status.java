package com.example.shaheenjaha.serviceconnect;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Status extends AppCompatActivity {
    ListView listView;
    List list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        listView = findViewById(R.id.listitem);
        list = new ArrayList();
        SharedPreferences sharedPreferences = getSharedPreferences("student_data", Context.MODE_PRIVATE);
        new AsynchClass().execute(sharedPreferences.getString("s_reg_no","default"));
       Boolean net= isNetworkAvailable();
       if(!net){
           Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
       }

    }

    public class AsynchClass extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... arg) {

            String regNo = arg[0];
            String data1="";
            int tmp1;
            try{

                URL url=new URL ("https://aec.edu.in/service_connect/app/ProcessingStatus.php");
                String urlParams="registration="+regNo;
                HttpURLConnection httpURLConnection=(HttpURLConnection) url.openConnection();
                httpURLConnection.setDoOutput(true);
                OutputStream os=httpURLConnection.getOutputStream();
                os.write(urlParams.getBytes());
                os.flush();
                os.close();
                InputStream is=httpURLConnection.getInputStream();
                while ((tmp1=is.read())!=-1){
                    data1+=(char)tmp1;
                }
                is.close();
                httpURLConnection.disconnect();
                return data1;
            }
            catch (MalformedURLException e){
                e.printStackTrace();
                return "Exception:"+e.getMessage();
            }
            catch (IOException e){
                e.printStackTrace();
                return "Exception:"+e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            try {
                JSONArray jsonArray = new JSONArray(s);
                for(int i=0;i<jsonArray.length();i++)
                {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String des = jsonObject.getString("description");
                    String cat = jsonObject.getString("category");
                    String compId = jsonObject.getString("complain_id");
                    String date = jsonObject.getString("date_time").substring(0,10);
                    ComplaintDataList complaintData = new ComplaintDataList(des,cat,compId,date);
                    list.add(complaintData);
                }
                CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(),R.layout.complaintstatus,list);
                listView.setAdapter(customAdapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class ComplaintDataList {
        String s_des;
        String s_cat;
        String s_comId;
        String s_date;
        private ComplaintDataList(String des, String cat, String comId, String date){
            s_des = des;
            s_cat = cat;
            s_comId = comId;
            s_date = date;
        }
        String getDes(){return s_des;}
        String getCat(){return s_cat;}
        String getCompid(){return s_comId;}
        String getDate(){return s_date;}
    }

    private class CustomAdapter extends ArrayAdapter<ComplaintDataList>{

        Context context;

        public CustomAdapter(Context context,int resource,List<ComplaintDataList> objects) {
            super(context, resource, objects);
            List<ComplaintDataList> list = objects;
            this.context = context;
            int res = resource;
        }

        @Override
        public View getView(int position,View convertView,ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.complaintstatus,null,true);
            ComplaintDataList complaintDataList = getItem(position);
            TextView cat = convertView.findViewById(R.id.cat);
            cat.setText(complaintDataList.getCat());
            TextView date = convertView.findViewById(R.id.date);
            date.setText(complaintDataList.getDate());
            TextView desc = convertView.findViewById(R.id.desc);
            desc.setText(complaintDataList.getDes());
            TextView code = convertView.findViewById(R.id.code);
            code.setText(complaintDataList.getCompid());
            return convertView;
        }
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}